"""
MessageProcessor - 前台消息处理器
负责将 ConversationLedger 中的内部消息格式转换为上游 LLM 请求的 context 消息格式。

主要转换逻辑：
1. 识别工具调用/结果消息：保持原始结构，确保兼容性
2. 图片转述处理：使用 ConversationLedger 中已生成的 image_caption，移除原始图片组件
3. 文本格式化：为消息添加结构化标签，增强 LLM 对上下文的理解
4. 内容标准化：统一 content 字段格式，兼容纯文本和多模态模型

输入：conversation_ledger.py 中的原始消息字典
输出：上游 Provider 可用的标准化 context 消息字典
"""

import copy
from datetime import datetime, timezone, timedelta
from typing import Any, List, Dict

from .utils import format_message_to_text


class MessageProcessor:
    """
    前台消息处理器 - 负责将 ConversationLedger 的内部消息转换为上游 context 消息

    转换职责：
    - 工具调用识别与保留：保持 assistant 角色的 tool_calls 结构
    - 工具结果透传：保持 tool 角色的结果消息原样传递
    - 图片转述处理：使用 ConversationLedger 中已生成的 image_caption，移除原始图片组件，适配纯文本模型
    - 文本格式化：为消息添加结构化包装标签，区分历史/最新消息
    - 多模态内容构建：整合文本描述与原始图片组件，支持图片模型

    输入消息来自 conversation_ledger.py 的 get_context_snapshot() 方法
    输出用于 rewrite_prompt_for_llm() 方法构建完整的 LLM 请求体
    """

    def __init__(self, alias: str):
        self.alias = alias

    def process_message(self, msg: Dict[str, Any]) -> Dict[str, Any]:
        """
        处理单条消息，将 ConversationLedger 内部格式转换为上游 context 消息

        Args:
            msg: ConversationLedger 中的原始消息字典，包含 role, content, timestamp, image_caption 等字段

        Returns:
            处理后的消息字典，标准化为上游 Provider 可接受的格式：
            - 工具调用消息：保持 tool_calls 结构，转换为字典格式
            - 工具结果消息：保持原样传递
            - 普通消息：使用已有的图片转述，文本格式化，构建多模态/纯文本 content
        """
        # 检查是否为原生工具调用或结果，如果是，则直接保留
        if self._is_tool_call(msg):
            return self._handle_tool_call(msg)
        if self._is_tool_result(msg):
            return self._handle_tool_result(msg)

        # 处理普通消息
        return self._handle_regular_message(msg)

    def _is_tool_call(self, msg: Dict[str, Any]) -> bool:
        """判断是否为工具调用消息"""
        return msg.get("role") == "assistant" and msg.get("tool_calls")

    def _is_tool_result(self, msg: Dict[str, Any]) -> bool:
        """判断是否为工具结果消息"""
        return msg.get("role") == "tool"

    def _handle_tool_call(self, msg: Dict[str, Any]) -> Dict[str, Any]:
        """处理工具调用消息"""
        dict_msg = msg.copy()
        # 使用 .model_dump() 将 Pydantic 对象转换为字典
        tool_calls = msg.get("tool_calls", [])
        if tool_calls and hasattr(tool_calls[0], 'model_dump'):
            dict_msg["tool_calls"] = [tc.model_dump() for tc in tool_calls]
        return dict_msg

    def _handle_tool_result(self, msg: Dict[str, Any]) -> Dict[str, Any]:
        """处理工具结果消息（通常已经是字典，直接返回）"""
        return msg.copy()

    def _handle_regular_message(self, msg: Dict[str, Any]) -> Dict[str, Any]:
        """处理普通消息（使用已有的图片转述、文本格式化等）"""
        # 预处理消息内容：使用已有的图片转述和多模态内容
        processed_msg = copy.deepcopy(msg)
        original_content = processed_msg.get("content", [])

        # 标准化 content 为列表格式
        content_list = self._normalize_content(original_content)

        # 使用 ConversationLedger 中已生成的图片转述
        image_caption = processed_msg.get("image_caption")
        if image_caption:
            content_list = self._remove_image_components(content_list)

        # 更新消息内容为处理后的列表
        processed_msg["content"] = content_list

        # 调用文本格式化工具生成结构化文本
        xml_content = format_message_to_text(processed_msg, self.alias)

        # 提取原始的图片组件
        image_components = self._extract_image_components(original_content)
        image_ref_text = self._build_image_refs_text(image_components)
        time_anchor_blocks = self._build_time_anchor_blocks(msg)

        # 构建最终内容
        role = msg.get("role", "user")
        # 强制规则：
        # 1. 助理消息：无条件字符串
        # 2. 用户消息：无图片 -> 字符串，有图片 -> 多模态列表
        if role == "assistant":
            final_content = xml_content  # 助理消息保持纯文本字符串
            if image_ref_text:
                final_content = f"{final_content}\n{image_ref_text}"
        elif not image_components:
            # 用户纯文本消息也使用文本块列表，方便追加时间锚点块
            final_content = [{"type": "text", "text": xml_content}]
            final_content.extend(time_anchor_blocks)
            if image_ref_text:
                final_content.append({"type": "text", "text": image_ref_text})
        else:
            # 只有用户消息且包含图片时，返回多模态列表
            final_content = [{"type": "text", "text": xml_content}]
            final_content.extend(time_anchor_blocks)
            if image_ref_text:
                final_content.append({"type": "text", "text": image_ref_text})
            final_content.extend(image_components)

        return {
            "role": role,
            "content": final_content
        }

    def _normalize_content(self, content: Any) -> List[Dict[str, Any]]:
        """标准化 content 为列表格式"""
        if isinstance(content, str):
            return [{"type": "text", "text": content}]
        elif isinstance(content, list):
            return content.copy()
        else:
            return [{"type": "text", "text": str(content)}]

    def _remove_image_components(self, content_list: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """移除图片组件，仅保留原有文本内容。"""
        return [item for item in content_list if item.get("type") != "image_url"]

    def _extract_image_components(self, original_content: Any) -> List[Dict[str, Any]]:
        """从原始内容中提取图片组件"""
        if not isinstance(original_content, list):
            return []

        return [
            item for item in original_content
            if item.get("type") == "image_url"
        ]

    def _build_image_refs_text(self, image_components: List[Dict[str, Any]]) -> str:
        """将图片组件中的可用引用拼接为文本，确保历史消息中也可见。"""
        if not image_components:
            return ""

        refs = []
        for item in image_components:
            if not isinstance(item, dict):
                continue
            ref = (
                item.get("local_file_path")
                or item.get("original_file_url")
                or item.get("original_url")
            )

            if not ref:
                image_url = item.get("image_url", {})
                if isinstance(image_url, dict):
                    url = image_url.get("url", "")
                    if isinstance(url, str) and url and not url.startswith("data:"):
                        ref = url

            if isinstance(ref, str) and ref:
                refs.append(ref)

        if not refs:
            return ""

        lines = [f"[Image Ref {idx}] {ref}" for idx, ref in enumerate(refs, start=1)]
        return "\n".join(lines)

    def _build_time_anchor_blocks(self, msg: Dict[str, Any]) -> List[Dict[str, str]]:
        """
        构建额外时间锚点文本块，使用消息发送时间（而非当前时间）。
        格式示例：2026-03-20 17:28 (CST)
        """
        cst = timezone(timedelta(hours=8))
        timestamp = msg.get("timestamp")
        try:
            if timestamp is not None:
                ts = float(timestamp)
                if ts > 0:
                    msg_dt = datetime.fromtimestamp(ts, cst).strftime("%Y-%m-%d %H:%M")
                    return [{"type": "text", "text": f"{msg_dt} (CST)"}]
        except (TypeError, ValueError, OSError):
            pass

        return []
