"""
向量存储组件.

封装所有与ChromaDB向量数据库的交互,通过依赖注入支持不同的嵌入提供商.
"""

import chromadb
import inspect
import re
from typing import Any, Dict, List, Optional, Tuple
import traceback
from pathlib import Path
from .embedding_provider import EmbeddingProvider
from ..utils.path_manager import PathManager
from .tag_manager import TagManager

# 导入日志记录器
try:
    from astrbot.api import logger
except ImportError:
    import logging

    logger = logging.getLogger(__name__)
from ..models.data_models import BaseMemory
from ..config.system_config import system_config


class VectorStore:
    """
    向量存储类.

    负责记忆的向量化和存储,使用ChromaDB作为后端.
    通过依赖注入接收嵌入提供商,实现解耦设计.
    """

    # 类级别的集合缓存,防止重复初始化
    _collection_cache = {}
    _cache_lock = None

    def __init__(
        self,
        embedding_provider: Optional[EmbeddingProvider] = None,
        db_path: Optional[str] = None,
        rerank_provider: Optional[Any] = None,
    ):
        """
        初始化向量存储.

        Args:
            embedding_provider: 嵌入提供商实例.如果未提供,则使用默认本地模型.
            db_path: 数据库存储路径.如果未提供,则从系统配置中获取.
        """
        self.logger = logger

        # 初始化线程锁(仅首次创建时)
        if VectorStore._cache_lock is None:
            import threading

            VectorStore._cache_lock = threading.RLock()

        # 初始化嵌入提供商
        if embedding_provider is None:
            # 不再强制降级，而是抛出明确错误
            self.logger.error("未指定嵌入提供商，无法初始化VectorStore")
            raise ValueError("VectorStore初始化需要有效的embedding_provider参数")
        else:
            self.embedding_provider = embedding_provider
            provider_info = embedding_provider.get_model_info()
            self.logger.info(f"使用嵌入提供商: {provider_info}")

            # API提供商在启动期必须可用；本地提供商允许懒加载
            if (
                embedding_provider.get_provider_type() != "local"
                and not embedding_provider.is_available()
            ):
                self.logger.error(f"指定的嵌入提供商不可用: {provider_info}")
                raise ValueError(
                    f"指定的嵌入提供商不可用: {provider_info.get('model_name', 'Unknown')}"
                )

        # 可选：上游重排提供商（仅用于记忆重排）
        self.rerank_provider = rerank_provider

        # 根据提供商类型确定数据库路径
        if db_path is None:
            provider_id = None
            if self.embedding_provider.get_provider_type() == "api":
                provider_info = self.embedding_provider.get_model_info()
                provider_id = provider_info.get("provider_id")

            self.db_path = str(system_config.get_database_path(provider_id))
        else:
            self.db_path = db_path

        # 创建ChromaDB客户端
        self.client = chromadb.PersistentClient(path=self.db_path)
        self.logger.info(f"已创建ChromaDB客户端,路径: {self.db_path}")

        # 实例变量
        self.collections = {}

        # ChromaDB是线程安全的,不需要额外的线程锁
        # 移除了 self._db_lock = threading.RLock()

        # 懒加载的标签管理器(用于基于 tag_ids 重建标签文本)
        self._tag_manager: Optional[TagManager] = None

    def _get_tag_manager(self) -> Optional[TagManager]:
        """懒加载 TagManager(基于 PathManager 当前 provider 和索引目录)."""
        if self._tag_manager is not None:
            return self._tag_manager
        try:
            pm = PathManager.get_instance()
            index_dir = str(pm.get_index_dir())
            provider_id = pm.get_current_provider()
            self._tag_manager = TagManager(index_dir, provider_id)
            return self._tag_manager
        except Exception as e:
            self.logger.warning(f"初始化 TagManager 失败: {e}")
            return None

    def _post_initialization_verification(self):
        """初始化完成后验证"""
        try:
            # 验证嵌入提供商
            if not self.embedding_provider.is_available():
                self.logger.error("嵌入提供商不可用！")
                return

            # 验证默认集合
            if hasattr(self, "collection") and self.collection:
                self._verify_collection_dimension(self.collection)

            # 验证所有已创建的集合
            for collection_name, collection in self.collections.items():
                self._verify_collection_dimension(collection)

        except Exception as e:
            self.logger.error(f"初始化后验证失败: {e}")
            self.logger.error(f"错误详情: {traceback.format_exc()}")

    def _verify_collection_dimension(self, collection):
        """
        验证集合维度是否与嵌入提供商匹配

        Args:
            collection: ChromaDB集合
        """
        try:
            # 获取嵌入提供商的维度信息
            provider_info = self.embedding_provider.get_model_info()
            if "dimension" in provider_info:
                expected_dimension = provider_info["dimension"]
                if not expected_dimension or expected_dimension <= 0:
                    return

                # 尝试用期望维度的向量查询
                dummy_vector = [0.0] * expected_dimension
                collection.query(query_embeddings=[dummy_vector], n_results=1)

        except Exception as e:
            if "dimension" in str(e).lower():
                self.logger.error(f"  ✗ 集合 {collection.name} 维度不匹配: {e}")
                # 记录集合当前的记录数
                count = collection.count()
                self.logger.info(f"  集合 {collection.name} 当前记录数: {count}")

    def set_storage_path(self, new_path: str):
        """
        设置新的存储路径并重新初始化ChromaDB客户端.

        注意:这将创建一个新的ChromaDB客户端,之前的数据仍在原路径中.
        如果需要迁移数据,请手动复制数据库文件.

        Args:
            new_path: 新的存储路径
        """
        try:
            # 创建新的ChromaDB客户端
            self.logger.info(f"正在切换存储路径到: {new_path}")
            new_client = chromadb.PersistentClient(path=new_path)

            # 更新共享客户端
            VectorStore._client = new_client
            self.client = new_client

            # 重新创建集合
            self.collection = self.client.get_or_create_collection(
                name=self.collection.name
            )

            self.logger.info(f"存储路径已成功切换到: {new_path}")

        except Exception as e:
            self.logger.error(f"切换存储路径失败: {e}")
            raise

    # ===== 笔记服务专用方法 =====

    def get_note_collection(self, collection_name: str = "notes_collection"):
        """
        获取笔记专用集合

        Args:
            collection_name: 集合名称

        Returns:
            ChromaDB集合对象
        """
        raise RuntimeError(
            "旧笔记向量集合接口已废弃（notes_collection/NoteData 链路）。"
            "请使用 NoteService + notes_index（中央SQL回查）新链路。"
        )

    async def remember(self, collection, memory: BaseMemory):
        """
        记住一条新记忆.

        Args:
            collection: 目标 ChromaDB 集合.
            memory: 要记住的记忆对象(任何 BaseMemory 的子类)
        """
        # 获取用于向量化的语义核心文本
        semantic_core = memory.get_semantic_core()

        # 获取记忆的内容文本(用于文档存储)
        content_text = ""
        if hasattr(memory, "content"):
            content_text = memory.content
        elif hasattr(memory, "definition"):
            content_text = memory.definition
        elif hasattr(memory, "procedure"):
            content_text = memory.procedure
        else:
            content_text = semantic_core  # 兜底方案

        # 使用高级抽象方法存储记忆
        await self.upsert_documents(
            collection=collection,
            ids=memory.id,
            embedding_texts=semantic_core,  # 用于向量化的语义核心
            documents=content_text,  # 实际存储的内容
            metadatas=memory.to_dict(),
        )

    @staticmethod
    def _build_query_where_clause(where_filter: Optional[dict]) -> Optional[dict]:
        """
        统一组装 Chroma where 条件。

        约定：
        - 顶层已是操作符（如 $and/$or）时，直接透传。
        - 普通 KV 条件按历史逻辑拼接。
        """
        if not where_filter:
            return None

        if any(str(key).startswith("$") for key in where_filter.keys()):
            return where_filter

        if len(where_filter) == 1:
            return where_filter

        return {"$and": [{k: v} for k, v in where_filter.items()]}

    async def recall(
        self,
        collection,
        query: str,
        limit: int = 10,
        where_filter: Optional[dict] = None,
        similarity_threshold: float = 0.6,
    ) -> List[BaseMemory]:
        """
        根据查询回忆相关记忆,支持复杂的元数据过滤(异步方法).

        Args:
            collection: 目标 ChromaDB 集合.
            query: 搜索查询字符串
            limit: 返回结果的最大数量
            where_filter: 可选的元数据过滤器字典 (e.g., {"memory_type": "EventMemory", "is_consolidated": False})
            similarity_threshold: 相似度阈值(0.0-1.0),低于此阈值的结果将被过滤

        Returns:
            相关的记忆对象列表(BaseMemory 的子类)
        """
        # 显式生成查询向量(异步调用)，指明这是查询场景
        query_embedding = await self.embed_single_document(query, is_query=True)

        # --- 处理向量化失败 ---
        if query_embedding is None:
            self.logger.warning(
                f"因向量化失败，查询 '{query[:50]}...' 的回忆流程已中止。"
            )
            return []  # 立即返回空列表

        # 构建查询参数 - 获取更多候选结果用于阈值过滤
        query_params = {
            "query_embeddings": [query_embedding],
            "n_results": limit * 3,  # 获取3倍候选结果进行过滤
        }

        # 如果提供了过滤器,则添加到查询参数
        where_clause = self._build_query_where_clause(where_filter)
        if where_clause:
            query_params["where"] = where_clause

        # 在ChromaDB中进行向量相似度搜索(数据库内部处理并发)
        results = collection.query(**query_params)

        # 将结果转换为记忆对象,并计算相似度分数进行过滤
        vector_results = []
        if results and results["metadatas"] and len(results["metadatas"]) > 0:
            ids = results.get("ids", [[]])[0]
            distances = results.get("distances", [[]])[0]
            metadatas = results["metadatas"][0]

            for idx, meta in enumerate(metadatas):
                if meta and idx < len(distances) and idx < len(ids):
                    # 将真实ID添加到meta中
                    meta["id"] = ids[idx]

                    # 计算相似度分数
                    distance = distances[idx]
                    similarity = max(0.0, 1.0 - (distance / 2.0))

                    # 应用相似度阈值过滤
                    if similarity >= similarity_threshold:
                        memory = BaseMemory.from_dict(meta)
                        memory.similarity = similarity  # 设置相似度属性
                        vector_results.append(memory)

                        # 只记录前3个结果的调试信息
                        if len(vector_results) <= 3:
                            self.logger.debug(
                                f"记忆{len(vector_results) - 1}: distance={distance:.4f}, similarity={similarity:.4f}"
                            )

                    # 达到所需数量时停止
                    if len(vector_results) >= limit:
                        break

        # 二阶段重排（通过上游 rerank_provider）
        final_results = await self._rerank_results(query, vector_results, collection, limit)

        return final_results

    async def recall_with_vector(
        self,
        collection,
        vector: List[float],
        query: str,
        limit: int = 10,
        where_filter: Optional[dict] = None,
        similarity_threshold: float = 0.6,
    ) -> List[BaseMemory]:
        """
        使用预计算的向量回忆相关记忆,支持复杂的元数据过滤.

        Args:
            collection: 目标 ChromaDB 集合.
            vector: 预计算的查询向量
            query: 原始查询文本，用于二阶段语义重排
            limit: 返回结果的最大数量
            where_filter: 可选的元数据过滤器字典 (e.g., {"memory_type": "EventMemory", "is_consolidated": False})
            similarity_threshold: 相似度阈值(0.0-1.0),低于此阈值的结果将被过滤

        Returns:
            相关的记忆对象列表(BaseMemory 的子类)
        """
        # 构建查询参数 - 获取更多候选结果用于阈值过滤
        query_params = {
            "query_embeddings": [vector],
            "n_results": limit * 3,  # 获取3倍候选结果进行过滤
        }

        # 如果提供了过滤器,则添加到查询参数
        where_clause = self._build_query_where_clause(where_filter)
        if where_clause:
            query_params["where"] = where_clause

        # 在ChromaDB中进行向量相似度搜索(数据库内部处理并发)
        results = collection.query(**query_params)

        # 将结果转换为记忆对象,并计算相似度分数进行过滤
        vector_results = []
        if results and results["metadatas"] and len(results["metadatas"]) > 0:
            ids = results.get("ids", [[]])[0]
            distances = results.get("distances", [[]])[0]
            metadatas = results["metadatas"][0]

            for idx, meta in enumerate(metadatas):
                if meta and idx < len(distances) and idx < len(ids):
                    # 将真实ID添加到meta中
                    meta["id"] = ids[idx]

                    # 计算相似度分数
                    distance = distances[idx]
                    similarity = max(0.0, 1.0 - (distance / 2.0))

                    # 应用相似度阈值过滤
                    if similarity >= similarity_threshold:
                        memory = BaseMemory.from_dict(meta)
                        memory.similarity = similarity  # 设置相似度属性
                        vector_results.append(memory)

                        # 只记录前3个结果的调试信息
                        if len(vector_results) <= 3:
                            self.logger.debug(
                                f"记忆{len(vector_results) - 1}: distance={distance:.4f}, similarity={similarity:.4f}"
                            )

                    # 达到所需数量时停止
                    if len(vector_results) >= limit:
                        break

        # 二阶段重排（通过上游 rerank_provider）
        final_results = await self._rerank_results(query, vector_results, collection, limit)

        return final_results

    async def update_memory(self, collection, memory_id, updates: dict = None):
        """
        更新记忆的元数据（支持单个或批量更新）.

        Args:
            collection: 目标 ChromaDB 集合.
            memory_id: 单个记忆ID（str）或批量更新列表（List[Dict]）
                - 单个: memory_id="id123", updates={"strength": 5}
                - 批量: memory_id=[{"id": "id1", "updates": {...}}, {"id": "id2", "updates": {...}}]
            updates: 单个更新时的字段字典 (e.g., {"is_consolidated": True, "strength": 5})
        """
        # 批量更新
        if isinstance(memory_id, list):
            try:
                ids = [item["id"] for item in memory_id]
                current_data = collection.get(ids=ids)

                if not current_data or not current_data["metadatas"]:
                    raise ValueError("No memories found for batch update")

                # 构建 ID 到数据的映射（collection.get 返回顺序不保证与输入一致）
                id_to_data = {}
                for i, mem_id in enumerate(current_data["ids"]):
                    id_to_data[mem_id] = {
                        "metadata": current_data["metadatas"][i],
                        "document": current_data["documents"][i] if current_data["documents"] and i < len(current_data["documents"]) else ""
                    }

                # 分组：需重算向量 vs 仅更新元数据
                reembed_batch = {
                    "ids": [], "texts": [], "docs": [], "metas": []
                }
                meta_only_batch = {
                    "ids": [], "metas": []
                }

                for item in memory_id:
                    mem_id = item["id"]
                    mem_updates = item["updates"]

                    # 用 ID 查找对应的数据
                    if mem_id not in id_to_data:
                        self.logger.warning(f"跳过记忆 {mem_id} 的批量更新：未找到数据")
                        continue

                    current_meta = id_to_data[mem_id]["metadata"]
                    current_document = id_to_data[mem_id]["document"]

                    # 检查是否需要重新向量化（仅当语义核心字段变更时）
                    # 注意：如果 updates 包含 judgment 或 tags，则必须重算向量
                    needs_reembed = "judgment" in mem_updates or "tags" in mem_updates

                    current_meta.update(mem_updates)

                    if needs_reembed:
                        semantic_core = current_meta.get("judgment", "") + " " + current_meta.get("tags", "")
                        reembed_batch["ids"].append(mem_id)
                        reembed_batch["texts"].append(semantic_core)
                        reembed_batch["docs"].append(current_document)
                        reembed_batch["metas"].append(current_meta)
                    else:
                        meta_only_batch["ids"].append(mem_id)
                        meta_only_batch["metas"].append(current_meta)

                # 1. 执行重向量化更新（耗时操作）
                if reembed_batch["ids"]:
                    await self.upsert_documents(
                        collection=collection,
                        ids=reembed_batch["ids"],
                        embedding_texts=reembed_batch["texts"],
                        documents=reembed_batch["docs"],
                        metadatas=reembed_batch["metas"],
                    )

                # 2. 执行仅元数据更新（快速操作）
                if meta_only_batch["ids"]:
                    collection.update(
                        ids=meta_only_batch["ids"],
                        metadatas=meta_only_batch["metas"]
                    )
                    self.logger.debug(f"快速更新了 {len(meta_only_batch['ids'])} 条记忆的元数据（跳过向量化）")

            except Exception as e:
                self.logger.error(f"批量更新记忆失败: {str(e)}")
                raise

        # 单个更新（向后兼容）
        else:
            try:
                current_data = collection.get(ids=[memory_id])
                if not current_data or not current_data["metadatas"]:
                    raise ValueError(f"Memory with id {memory_id} not found")

                current_meta = current_data["metadatas"][0]
                current_document = (
                    current_data["documents"][0] if current_data["documents"] else ""
                )

                # 检查是否需要重新向量化
                needs_reembed = updates and ("judgment" in updates or "tags" in updates)
                current_meta.update(updates)

                if needs_reembed:
                    semantic_core = (
                        current_meta.get("judgment", "") + " " + current_meta.get("tags", "")
                    )
                    await self.upsert_documents(
                        collection=collection,
                        ids=memory_id,
                        embedding_texts=semantic_core,
                        documents=current_document,
                        metadatas=current_meta,
                    )
                else:
                    collection.update(
                        ids=[memory_id],
                        metadatas=[current_meta]
                    )
                    self.logger.debug(f"快速更新了记忆 {memory_id} 的元数据（跳过向量化）")

            except Exception as e:
                self.logger.error(f"更新记忆 {memory_id} 失败: {str(e)}")
                raise

    def delete_memories(self, collection, where_filter: dict):
        """
        根据条件删除记忆.

        Args:
            collection: 目标 ChromaDB 集合.
            where_filter: 删除条件 (e.g., {"strength": {"$lt": 2}})
        """
        try:
            # 处理多个条件的查询
            if len(where_filter) > 1:
                # 使用 $and 操作符处理多个条件
                base_filter = {"$and": [{k: v} for k, v in where_filter.items()]}
            else:
                base_filter = where_filter

            # 获取符合条件的记忆ID
            results = collection.get(where=base_filter)
            ids_to_delete = results["ids"]

            if ids_to_delete:
                collection.delete(ids=ids_to_delete)
                self.logger.info(
                    f"Deleted {len(ids_to_delete)} memories with filter: {where_filter}"
                )

        except Exception as e:
            self.logger.error(f"Failed to delete memories: {str(e)}")
            raise

    def clear_collection(self, collection):
        """清空指定集合."""
        try:
            collection_name = collection.name
            # 先失效该集合相关缓存，避免后续先拿到已删除的旧句柄
            self.invalidate_cache_by_pattern(f":{collection_name}:")
            self.client.delete_collection(collection_name)
            # 重新创建集合,确保 embedding_function 等元数据被保留
            self.get_or_create_collection_with_dimension_check(name=collection_name)
        except Exception as e:
            self.logger.error(f"清空所有记忆失败: {e}")
            raise

    def _detect_max_batch_size(self) -> int:
        """
        尝试从 Chroma client 获取最大批量写入条数，失败时使用保守默认值。
        """
        candidates = []
        for attr in ("get_max_batch_size", "max_batch_size"):
            value = getattr(self.client, attr, None)
            if value is None:
                continue
            try:
                if callable(value):
                    value = value()
                candidates.append(int(value))
            except Exception:
                continue
        valid = [x for x in candidates if x > 0]
        if valid:
            return min(valid)
        # 保守默认值，避免大批次直接触发上限异常
        return 5000

    async def upsert_documents(
        self,
        collection,
        *,
        ids,
        embedding_texts,
        documents=None,
        metadatas=None,
        _return_timings=False,
    ):
        """
        高级 upsert 方法(异步接口):从文本生成向量并存储到向量数据库.

        这是向量数据库的通用方法,支持不同的使用场景:
        - 记忆系统:documents 参数可选,所有数据可存储在 metadatas 中
        - 笔记系统:documents 参数可选,正文可存储在 metadatas['content'] 中
        - 其他系统:可灵活选择使用 documents 字段

        Args:
            collection: 目标 ChromaDB 集合
            ids: 文档ID或ID列表
            embedding_texts: 用于生成向量的文本或文本列表
            documents: 可选的文档内容或列表(默认 None)
            metadatas: 与文档关联的元数据或元数据列表
            _return_timings: 内部参数,是否返回计时信息
        """
        import time

        timings = {} if _return_timings else None

        # 统一处理输入为列表
        ids_list = [ids] if isinstance(ids, str) else ids
        embedding_texts_list = (
            [embedding_texts] if isinstance(embedding_texts, str) else embedding_texts
        )
        documents_list = (
            [documents]
            if isinstance(documents, str)
            else documents
            if documents is not None
            else None
        )
        metadatas_list = [metadatas] if isinstance(metadatas, dict) else metadatas

        if not ids_list:
            return timings if _return_timings else None

        max_batch_size = self._detect_max_batch_size()
        total = len(ids_list)

        total_embed_ms = 0.0
        total_db_ms = 0.0
        pos = 0
        while pos < total:
            end = min(pos + max_batch_size, total)
            batch_ids = ids_list[pos:end]
            batch_texts = embedding_texts_list[pos:end]
            batch_docs = documents_list[pos:end] if documents_list is not None else None
            batch_metas = metadatas_list[pos:end] if metadatas_list is not None else None

            # 1) 先向量化当前批次
            t_embed = time.time()
            embeddings = await self.embed_documents(batch_texts)
            total_embed_ms += (time.time() - t_embed) * 1000

            # 2) 写入当前批次
            upsert_params = {
                "ids": batch_ids,
                "embeddings": embeddings,
            }
            if batch_docs is not None:
                upsert_params["documents"] = batch_docs
            if batch_metas is not None:
                upsert_params["metadatas"] = batch_metas

            t_db = time.time()
            try:
                collection.upsert(**upsert_params)
            except ValueError as e:
                msg = str(e)
                match = re.search(r"max batch size of (\d+)", msg)
                # 防御性降级：若服务端上限更小，动态收敛后重试本批次
                if match:
                    detected_limit = int(match.group(1))
                    if detected_limit > 0 and detected_limit < max_batch_size:
                        max_batch_size = detected_limit
                        continue
                raise
            total_db_ms += (time.time() - t_db) * 1000
            pos = end

        if _return_timings:
            timings["embed"] = total_embed_ms
            timings["db_upsert"] = total_db_ms

        return timings if _return_timings else None

    async def upsert_memory_index_rows(
        self,
        collection,
        rows: List[Dict[str, str]],
    ) -> None:
        """
        轻量记忆索引写入：仅写 id + vector_text + embedding。

        rows: [{"id": "...", "vector_text": "..."}]
        """
        if not rows:
            return

        ids: List[str] = []
        texts: List[str] = []
        metadatas: List[Dict[str, str]] = []

        for row in rows:
            memory_id = str(row.get("id") or "").strip()
            vector_text = str(row.get("vector_text") or "").strip()
            if not memory_id or not vector_text:
                continue
            ids.append(memory_id)
            texts.append(vector_text)
            # 仅保留最小冗余字段，业务数据回 SQL 查。
            metadatas.append({"memory_id": memory_id})

        if not ids:
            return

        await self.upsert_documents(
            collection=collection,
            ids=ids,
            embedding_texts=texts,
            documents=texts,
            metadatas=metadatas,
        )

    async def recall_memory_ids(
        self,
        collection,
        query: str,
        limit: int = 10,
        vector: Optional[List[float]] = None,
        similarity_threshold: float = 0.5,
    ) -> List[Tuple[str, float]]:
        """
        轻量记忆索引召回：仅返回 (memory_id, similarity)。
        """
        query_vector = vector
        if query_vector is None:
            query_vector = await self.embed_single_document(query, is_query=True)
        if query_vector is None:
            return []

        results = collection.query(
            query_embeddings=[query_vector],
            n_results=max(1, int(limit)),
        )

        ids = (results or {}).get("ids", [[]])
        distances = (results or {}).get("distances", [[]])
        flat_ids = ids[0] if ids else []
        flat_distances = distances[0] if distances else []

        recalled: List[Tuple[str, float]] = []
        for idx, memory_id in enumerate(flat_ids):
            distance = (
                flat_distances[idx] if idx < len(flat_distances) else 2.0
            )
            similarity = max(0.0, 1.0 - (float(distance) / 2.0))
            if similarity < similarity_threshold:
                continue
            recalled.append((str(memory_id), similarity))
        return recalled

    async def upsert_note_index_rows(
        self,
        collection,
        rows: List[Dict[str, str]],
    ) -> None:
        """轻量笔记索引写入：仅写 source_id + vector_text。"""
        if not rows:
            return

        ids: List[str] = []
        texts: List[str] = []
        metadatas: List[Dict[str, str]] = []
        for row in rows:
            source_id = str(row.get("id") or "").strip()
            vector_text = str(row.get("vector_text") or "").strip()
            if not source_id or not vector_text:
                continue
            ids.append(source_id)
            texts.append(vector_text)
            metadatas.append({"source_id": source_id})

        if not ids:
            return

        await self.upsert_documents(
            collection=collection,
            ids=ids,
            embedding_texts=texts,
            documents=texts,
            metadatas=metadatas,
        )

    async def recall_note_source_ids(
        self,
        collection,
        query: str,
        limit: int = 10,
        vector: Optional[List[float]] = None,
        similarity_threshold: float = 0.5,
    ) -> List[Tuple[str, float]]:
        """轻量笔记索引召回：仅返回 (source_id, similarity)。"""
        query_vector = vector
        if query_vector is None:
            query_vector = await self.embed_single_document(query, is_query=True)
        if query_vector is None:
            return []

        results = collection.query(
            query_embeddings=[query_vector],
            n_results=max(1, int(limit)),
        )
        ids = (results or {}).get("ids", [[]])
        distances = (results or {}).get("distances", [[]])
        flat_ids = ids[0] if ids else []
        flat_distances = distances[0] if distances else []

        recalled: List[Tuple[str, float]] = []
        for idx, source_id in enumerate(flat_ids):
            distance = flat_distances[idx] if idx < len(flat_distances) else 2.0
            similarity = max(0.0, 1.0 - (float(distance) / 2.0))
            if similarity < similarity_threshold:
                continue
            recalled.append((str(source_id), similarity))
        return recalled

    async def embed_documents(
        self, documents: List[str], is_query: bool = False, timeout: int = 3
    ) -> Optional[List[List[float]]]:
        """
        使用嵌入提供商为文档列表生成向量嵌入(异步方法).

        Args:
            documents: 需要进行向量化的文档字符串列表.
            is_query: 是否为查询场景. True=性能敏感的查询场景, False=可靠的存储场景.
            timeout: 查询场景下的超时时间(秒), 仅在 is_query=True 时生效.

        Returns:
            一个由向量(浮点数列表)组成的列表, 或在查询失败时返回 None.

        Raises:
            RateLimitExceededError: 仅在存储场景(is_query=False)下, 当重试3次后仍然遇到429错误时抛出
            Exception: 其他错误直接抛出,不重试
        """
        if not documents:
            return []

        # --- 性能敏感的查询路径 ---
        if is_query:
            try:
                # 查询场景输入净化：避免把空文本/超长文本传给上游导致 400 参数错误
                sanitized_docs: List[str] = []
                max_query_chars = 4000
                for doc in documents:
                    text = str(doc or "").strip()
                    if not text:
                        self.logger.warning("查询向量化收到空文本，已跳过本次查询。")
                        return None
                    if len(text) > max_query_chars:
                        self.logger.debug(
                            f"查询文本过长，已截断: 原长度={len(text)} 截断后={max_query_chars}"
                        )
                        text = text[:max_query_chars]
                    sanitized_docs.append(text)

                # 使用 asyncio.wait_for 实现超时控制
                import asyncio
                embeddings = await asyncio.wait_for(
                    self.embedding_provider.embed_documents(sanitized_docs),
                    timeout=timeout
                )
                return embeddings
            except asyncio.TimeoutError:
                self.logger.warning(
                    f"查询向量化超时（超过 {timeout} 秒），操作已中断。"
                )
                return None
            except Exception as e:
                self.logger.error(f"查询向量化失败，立即返回。错误: {e}")
                return None

        # --- 可靠的存储路径 (保留现有重试逻辑) ---
        else:
            # 导入自定义异常
            from ..exceptions import RateLimitExceededError
            import asyncio

            # 重试配置(仅针对429错误)
            max_retries = 3
            base_wait_time = 60  # 基础等待时间(秒)

            for attempt in range(max_retries):
                try:
                    # 使用嵌入提供商生成向量(异步调用)
                    embeddings = await self.embedding_provider.embed_documents(documents)
                    return embeddings

                except Exception as e:
                    error_msg = str(e)

                    # 只对429错误进行重试,其他错误直接抛出
                    is_rate_limit = (
                        "429" in error_msg
                        or "rate limit" in error_msg.lower()
                        or "TPM limit" in error_msg
                    )

                    if not is_rate_limit:
                        # 非429错误,直接抛出,不重试
                        self.logger.error(f"❌ 向量化失败: {error_msg}")
                        raise

                    # 429错误的重试逻辑
                    if attempt < max_retries - 1:
                        # 指数退避:60s, 120s, 240s
                        wait_time = base_wait_time * (2**attempt)

                        # 添加随机抖动(±10%)避免同时重试
                        import random

                        jitter = random.uniform(-0.1, 0.1) * wait_time
                        final_wait = int(wait_time + jitter)

                        self.logger.warning(
                            f"⏱️  遇到速率限制 (429错误),"
                            f"等待 {final_wait} 秒后重试 "
                            f"(第 {attempt + 1}/{max_retries} 次)"
                        )

                        await asyncio.sleep(final_wait)
                    else:
                        # 达到最大重试次数,抛出自定义异常
                        self.logger.error(
                            f"❌ 向量化失败:达到最大重试次数 ({max_retries}),"
                            f"速率限制错误: {error_msg}"
                        )
                        raise RateLimitExceededError(
                            f"速率限制重试失败 (尝试了{max_retries}次): {error_msg}",
                            attempts=max_retries,
                        ) from e

            # 理论上不会到这里
            raise Exception("向量化失败:未知错误")

    async def embed_single_document(
        self, document: str, is_query: bool = False, timeout: int = 3
    ) -> Optional[List[float]]:
        """
        为单个文档生成向量嵌入(异步方法).

        Args:
            document: 需要向量化的单个文档字符串.
            is_query: 是否为查询场景.
            timeout: 查询场景下的超时时间(秒).

        Returns:
            单个文档的向量, 或在查询失败时返回 None.
        """
        if not str(document or "").strip():
            return None
        embeddings = await self.embed_documents(
            [document], is_query=is_query, timeout=timeout
        )
        if embeddings:
            return embeddings[0]
        return None

    async def embed_text_direct(self, text: str, is_query: bool = False, timeout: int = 3) -> Optional[List[float]]:
        """
        直接向量化文本，不经过复杂处理和缓存

        Args:
            text: 需要向量化的文本
            is_query: 是否为查询场景，影响超时和重试策略
            timeout: 查询场景下的超时时间(秒)

        Returns:
            文本的向量表示，失败时返回None
        """
        if not text or not text.strip():
            return None

        # 直接调用底层的嵌入提供商，避免额外处理
        try:
            if is_query:
                # 查询场景：使用超时控制
                import asyncio
                embeddings = await asyncio.wait_for(
                    self.embedding_provider.embed_documents([text]),
                    timeout=timeout
                )
                return embeddings[0] if embeddings else None
            else:
                # 存储场景：直接调用
                embeddings = await self.embedding_provider.embed_documents([text])
                return embeddings[0] if embeddings else None
        except Exception as e:
            self.logger.debug(f"直接向量化失败: {e}")
            return None



    def get_or_create_collection_with_dimension_check(self, name: str):
        """
        获取或创建集合,并检查维度是否匹配
        完善的集合缓存机制,防止重复初始化

        Args:
            name: 集合名称

        Returns:
            ChromaDB集合对象
        """
        # 构建更精确的缓存键,包含路径、模型、提供商信息
        provider_info = self.embedding_provider.get_model_info()
        model_name = provider_info.get("model_name", "default")
        provider_type = self.embedding_provider.get_provider_type()

        # 使用绝对路径确保唯一性
        abs_db_path = str(Path(self.db_path).resolve())
        cache_key = f"{abs_db_path}:{name}:{model_name}:{provider_type}"

        with VectorStore._cache_lock:
            if cache_key in VectorStore._collection_cache:
                cached_collection = VectorStore._collection_cache[cache_key]
                # 简单验证缓存集合是否仍然有效
                try:
                    # 尝试访问集合的count方法验证连接
                    cached_collection.count()
                    self.logger.debug(f"✅ 从缓存获取集合: {name}")
                    return cached_collection
                except Exception as e:
                    # 缓存集合无效,删除缓存项
                    self.logger.debug(f"缓存集合失效，自动重建: {name}, 原因: {e}")
                    del VectorStore._collection_cache[cache_key]

        # 获取集合前先记录详细信息
        self.logger.info(f"正在获取或创建集合: {name}")

        # 统一由 provider 在业务层完成向量化，避免 Chroma 侧独立加载模型。
        embedding_function = None
        collection = self.client.get_or_create_collection(
            name=name, embedding_function=embedding_function
        )

        # 检查集合维度(仅对本地模型)
        if self.embedding_provider.get_provider_type() == "local":
            self._verify_collection_dimension(collection)

        # 缓存集合
        with VectorStore._cache_lock:
            VectorStore._collection_cache[cache_key] = collection
            self.logger.debug(
                f"✅ 集合已缓存: {name}, 缓存大小: {len(VectorStore._collection_cache)}"
            )

        return collection

    @classmethod
    def clear_collection_cache(cls):
        """
        清空集合缓存(用于测试或强制重建)
        """
        with cls._cache_lock:
            cache_size = len(cls._collection_cache)
            cls._collection_cache.clear()
            if hasattr(cls, "logger"):
                cls.logger.info(f"✅ 集合缓存已清空,清理了 {cache_size} 个缓存项")

    @classmethod
    def get_cache_statistics(cls):
        """
        获取集合缓存统计信息

        Returns:
            缓存统计字典
        """
        with cls._cache_lock:
            cache_size = len(cls._collection_cache)
            cache_keys = list(cls._collection_cache.keys())

            # 分析缓存键模式
            db_paths = set()
            collections = set()
            models = set()

            for key in cache_keys:
                parts = key.split(":")
                if len(parts) >= 4:
                    db_paths.add(parts[0])
                    collections.add(parts[1])
                    models.add(parts[2])

            return {
                "cache_size": cache_size,
                "unique_databases": len(db_paths),
                "unique_collections": len(collections),
                "unique_models": len(models),
                "cache_keys": cache_keys,
            }

    @classmethod
    def invalidate_cache_by_pattern(cls, pattern: str):
        """
        根据模式失效缓存项

        Args:
            pattern: 模式字符串,支持部分匹配
        """
        with cls._cache_lock:
            keys_to_remove = [
                key for key in cls._collection_cache.keys() if pattern in key
            ]

            for key in keys_to_remove:
                del cls._collection_cache[key]

            if hasattr(cls, "logger"):
                cls.logger.info(
                    f"✅ 失效了 {len(keys_to_remove)} 个匹配模式 '{pattern}' 的缓存项"
                )

    # ===== 混合检索集成方法 =====

    async def _rerank_results(
        self, query: str, vector_results: List[BaseMemory], collection, limit: int
    ) -> List[BaseMemory]:
        """记忆二阶段重排（优先使用上游 rerank_provider，失败时降级为向量排序）。"""
        if not vector_results:
            return []

        # 没有可用重排器：直接采用向量相似度排序结果
        if not self.rerank_provider or not hasattr(self.rerank_provider, "rerank"):
            return vector_results[:limit]

        try:
            passages = []
            documents: List[str] = []
            id_to_index: Dict[str, int] = {}
            for idx, mem in enumerate(vector_results):
                mem_id = getattr(mem, "id", f"mem_{idx}")
                id_to_index[mem_id] = idx

                text = ""
                if hasattr(mem, "get_semantic_core"):
                    text = mem.get_semantic_core() or ""
                if not text:
                    judgment = getattr(mem, "judgment", "") or ""
                    reasoning = getattr(mem, "reasoning", "") or ""
                    text = f"{judgment}\n{reasoning}".strip()

                safe_text = str(text or "").strip()
                passages.append({"id": mem_id, "text": safe_text})
                documents.append(safe_text)

            rerank_method = self.rerank_provider.rerank
            safe_query = str(query or "")

            # 只使用标准签名：query + documents
            rerank_resp = rerank_method(
                query=safe_query,
                documents=documents,
            )

            if inspect.isawaitable(rerank_resp):
                rerank_resp = await rerank_resp

            if isinstance(rerank_resp, dict) and rerank_resp.get("code") not in (None, 0, 200, "0", "200"):
                self.logger.warning(f"记忆重排接口返回非成功状态，降级为向量排序: {rerank_resp}")
                return vector_results[:limit]

            ranked_scores = self._extract_ranked_scores(rerank_resp, passages, id_to_index)
            if not ranked_scores:
                return vector_results[:limit]

            reordered = self._reorder_results_by_score(vector_results, ranked_scores, collection)
            return reordered[:limit]
        except Exception as e:
            self.logger.warning(f"记忆重排失败，降级为向量排序: {e}")
            return vector_results[:limit]

    def _extract_ranked_scores(
        self,
        rerank_resp: Any,
        passages: List[Dict[str, str]],
        id_to_index: Dict[str, int],
    ) -> List[Tuple[str, float]]:
        """兼容多种上游 rerank 返回格式，归一化为 [(doc_id, score)]。"""
        if rerank_resp is None:
            return []

        # 常见返回：{"results": [...]}
        if isinstance(rerank_resp, dict):
            items = rerank_resp.get("results")
            if items is None:
                data = rerank_resp.get("data")
                if isinstance(data, list):
                    items = data
                elif isinstance(data, dict):
                    items = data.get("results") or data.get("items")
        else:
            items = rerank_resp

        if not isinstance(items, list):
            return []

        ranked_scores: List[Tuple[str, float]] = []
        for item in items:
            if item is None:
                continue

            doc_id = None
            score = None

            if isinstance(item, dict):
                doc_id = item.get("id")
                score = item.get("score")

                # 兼容 index 返回
                if doc_id is None and "index" in item:
                    idx = item.get("index")
                    if isinstance(idx, int) and 0 <= idx < len(passages):
                        doc_id = passages[idx]["id"]

                # 兼容 text/document 返回
                if doc_id is None:
                    text = item.get("text") or item.get("document") or ""
                    for p in passages:
                        if p["text"] == text:
                            doc_id = p["id"]
                            break
            else:
                doc_id = getattr(item, "id", None)
                score = getattr(item, "score", None)
                if doc_id is None and hasattr(item, "index"):
                    idx = getattr(item, "index")
                    if isinstance(idx, int) and 0 <= idx < len(passages):
                        doc_id = passages[idx]["id"]

            if doc_id in id_to_index and score is not None:
                try:
                    ranked_scores.append((doc_id, float(score)))
                except Exception:
                    continue

        return ranked_scores

    def _reorder_results_by_score(
        self,
        original_results: List[BaseMemory],
        ranked_scores: List[Tuple[str, float]],
        collection
    ) -> List[BaseMemory]:
        """
        根据 3:7 加权融合策略重新排序结果
        Score = 0.3 * VectorScore + 0.7 * RerankScore

        策略：
        1. 如果重排失败 (ranked_scores为空)，则默认重排分数为 1.0 (保留向量排序)
        2. 如果重排成功但截断了结果，未在 ranked_scores 中的项默认分数为 0.0
        3. 始终保留所有原始候选结果，防止数据丢失
        """
        # 1. 准备重排分数逻辑
        rerank_score_map = {}
        default_rerank_score = 0.0

        if ranked_scores:
            rerank_score_map = {doc_id: score for doc_id, score in ranked_scores}
            # 既然重排返回了结果，说明未选中的确实相关性低，给 0.0
            default_rerank_score = 0.0
        else:
            # 重排失败或未返回任何结果，为了保持原有向量排序并归一化，给予满分 1.0
            # 这样 Final = 0.3 * Vector + 0.7 * 1.0，顺序由 Vector 决定
            default_rerank_score = 1.0

        fused_results = []

        # 2. 遍历所有原始结果（确保不丢失数据）
        for mem in original_results:
            # 获取重排分数
            rerank_score = rerank_score_map.get(mem.id, default_rerank_score)

            # 获取向量分数
            vector_score = getattr(mem, "similarity", 0.0)

            # 核心公式: 0.3 * Vector + 0.7 * Rerank
            final_score = (0.3 * vector_score) + (0.7 * rerank_score)

            mem.similarity = final_score
            fused_results.append(mem)

        # 3. 重新按融合分数排序
        fused_results.sort(key=lambda x: x.similarity, reverse=True)

        return fused_results

    def _get_memories_by_ids(self, collection, doc_ids: List[str]) -> List[BaseMemory]:
        """根据文档ID列表获取记忆对象"""
        try:
            if not doc_ids:
                return []

            # 使用ChromaDB的get方法获取指定ID的文档
            retrieved_docs = collection.get(ids=doc_ids)
            if not retrieved_docs or not retrieved_docs["metadatas"]:
                return []

            memories = []
            for meta in retrieved_docs["metadatas"]:
                if meta:
                    memories.append(BaseMemory.from_dict(meta))

            return memories

        except Exception as e:
            self.logger.error(f"根据ID获取记忆失败: {e}")
            return []

    # ===== 混合检索配置方法 =====

    @classmethod
    def get_cache_info(cls):
        """获取缓存信息(用于调试)"""
        with cls._cache_lock:
            return {
                "cache_size": len(cls._collection_cache),
                "cached_collections": list(cls._collection_cache.keys()),
            }

    def shutdown(self):
        """关闭向量存储,释放资源"""
        self.logger.info("正在关闭向量存储...")

        # 关闭嵌入提供商
        if self.embedding_provider:
            self.embedding_provider.shutdown()

        # 清理集合缓存
        self.clear_collection_cache()

        self.logger.info("向量存储已成功关闭")
